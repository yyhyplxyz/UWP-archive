#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"
#pragma execution_character_set("utf-8")

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}

// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }
	playerIsAnimating = false;
    visibleSize = Director::getInstance()->getVisibleSize();
    origin = Director::getInstance()->getVisibleOrigin();

	//����һ����ͼ
	auto texture = Director::getInstance()->getTextureCache()->addImage("$lucia_2.png");
	//����ͼ�������ص�λ�и�����ؼ�֡
	auto frame0 = SpriteFrame::createWithTexture(texture, CC_RECT_PIXELS_TO_POINTS(Rect(0, 0, 113, 113)));
	//ʹ�õ�һ֡��������
	player = Sprite::createWithSpriteFrame(frame0);
	player->setPosition(Vec2(origin.x + visibleSize.width / 2,
		origin.y + visibleSize.height / 2));
	addChild(player, 3);

	//hp��
	Sprite* sp0 = Sprite::create("hp.png", CC_RECT_PIXELS_TO_POINTS(Rect(0, 320, 420, 47)));
	Sprite* sp = Sprite::create("hp.png", CC_RECT_PIXELS_TO_POINTS(Rect(610, 362, 4, 16)));

	//ʹ��hp������progressBar
	pT = ProgressTimer::create(sp);
	pT->setScaleX(90);
	pT->setAnchorPoint(Vec2(0, 0));
	pT->setType(ProgressTimerType::BAR);
	pT->setBarChangeRate(Point(1, 0));
	pT->setMidpoint(Point(0, 1));
	pT->setPercentage(100);
	HPbarPercentage = 100;
	pT->setPercentage(HPbarPercentage);
	pT->setPosition(Vec2(origin.x + 14 * pT->getContentSize().width, origin.y + visibleSize.height - 2 * pT->getContentSize().height));
	addChild(pT, 1);
	sp0->setAnchorPoint(Vec2(0, 0));
	sp0->setPosition(Vec2(origin.x + pT->getContentSize().width, origin.y + visibleSize.height - sp0->getContentSize().height));
	addChild(sp0, 0);

	idle.reserve(1);
	idle.pushBack(frame0);
	attack.reserve(17);
	for (int i = 0; i < 17; i++) {
		auto frame = SpriteFrame::createWithTexture(texture, CC_RECT_PIXELS_TO_POINTS(Rect(113 * i, 0, 113, 113)));
		attack.pushBack(frame);
	}

	auto texture2 = Director::getInstance()->getTextureCache()->addImage("$lucia_dead.png");
	dead.reserve(22);
	for (int i = 0; i < 22; i++) {
		auto frame = SpriteFrame::createWithTexture(texture2, CC_RECT_PIXELS_TO_POINTS(Rect(79 * i, 0, 79, 90)));
		dead.pushBack(frame);
	}

	auto texture3 = Director::getInstance()->getTextureCache()->addImage("$lucia_forward.png");
	// Todo
	run.reserve(8);
	for (int i = 0; i < 8; i++) {
		auto frame = SpriteFrame::createWithTexture(texture3, CC_RECT_PIXELS_TO_POINTS(Rect(68 * i, 0, 68, 101)));
		run.pushBack(frame);
	}
	auto frame4 = SpriteFrame::createWithTexture(texture, CC_RECT_PIXELS_TO_POINTS(Rect(0, 0, 68, 101)));
	run.pushBack(frame4);
	TTFConfig ttfConfig;
	ttfConfig.fontFilePath = "fonts/arial.ttf";
	ttfConfig.fontSize = 36;

	//Label
	auto menuLabel1 = Label::createWithTTF(ttfConfig, "W");
	auto menuLabel2 = Label::createWithTTF(ttfConfig, "S");
	auto menuLabel3 = Label::createWithTTF(ttfConfig, "A");
	auto menuLabel4 = Label::createWithTTF(ttfConfig, "D");
	//menuItem
	auto item1 = MenuItemLabel::create(menuLabel1, CC_CALLBACK_0(HelloWorld::labelCallback, this, 'W'));
	auto item2 = MenuItemLabel::create(menuLabel2, CC_CALLBACK_0(HelloWorld::labelCallback, this, 'S'));
	auto item3 = MenuItemLabel::create(menuLabel3, CC_CALLBACK_0(HelloWorld::labelCallback, this, 'A'));
	auto item4 = MenuItemLabel::create(menuLabel4, CC_CALLBACK_0(HelloWorld::labelCallback, this, 'D'));
	
	item3->setPosition(Vec2(origin.x + item3->getContentSize().width, origin.y + item3->getContentSize().height));
	item4->setPosition(Vec2(item3->getPosition().x + 3 * item4->getContentSize().width, item3->getPosition().y));
	item2->setPosition(Vec2(item3->getPosition().x + 1.5*item2->getContentSize().width, item3->getPosition().y));
	item1->setPosition(Vec2(item2->getPosition().x, item2->getPosition().y + item1->getContentSize().height));
	time = Label::createWithTTF(ttfConfig, "180");
	time->setPosition(Vec2(origin.x + visibleSize.width / 2,
		origin.y + visibleSize.height - time->getContentSize().height));
	addChild(time);
	auto menu = Menu::create(item1, item2, item3, item4, NULL);
	menu->setPosition(Vec2(0, 0));
	addChild(menu, 1);

	auto label = Label::create("X", "arial", 36);
	auto menuItem = MenuItemLabel::create(label, CC_CALLBACK_1(HelloWorld::attackCallback, this));
	menuItem->setPosition(origin.x + visibleSize.width - 120, 10);
	menu->addChild(menuItem);


	label = Label::create("Y", "arial", 36);
	menuItem = MenuItemLabel::create(label, CC_CALLBACK_1(HelloWorld::deadCallback, this));
	menuItem->setPosition(origin.x + visibleSize.width - 100, 30);
	menu->addChild(menuItem);
	schedule(schedule_selector(HelloWorld::update), 1.0f);

	return true;
}

void HelloWorld::labelCallback (char cid)
{
	auto animation = Animation::createWithSpriteFrames(run, 0.08f);
	auto animate = Animate::create(animation);

	Point movement;
	if (cid == 'W') {
		if (player->getPositionY() < visibleSize.height) {
			Point p = Point(player->getPositionX(), player->getPositionY() + 30);
			auto move = MoveTo::create(0.4f, p);
			auto myspawn = Spawn::createWithTwoActions(move, animate);
			player->runAction(myspawn);
		}
	}
	if (cid == 'A') {
		if (player->getPositionX() > origin.x) {
			Point p = Point(player->getPositionX() - 30, player->getPositionY());
			auto move = MoveTo::create(0.4f, p);
			auto myspawn = Spawn::createWithTwoActions(move, animate);
			player->runAction(myspawn);
		}
	}
	if (cid == 'S') {
		if (player->getPositionY() > origin.y) {
			Point p = Point(player->getPositionX(), player->getPositionY() - 30);
			auto move = MoveTo::create(0.4f, p);
			auto myspawn = Spawn::createWithTwoActions(move, animate);
			player->runAction(myspawn);
		}
	}
	if (cid == 'D') {
		if (player->getPositionX() < visibleSize.width) {
			Point p = Point(player->getPositionX() + 30, player->getPositionY());
			auto move = MoveTo::create(0.4f, p);
			auto myspawn = Spawn::createWithTwoActions(move, animate);
			player->runAction(myspawn);
		}
	}
	
}


void HelloWorld::deadCallback(Ref * pSender)
{
	Animation* actionAnimation = nullptr;
	if (playerIsAnimating == false) {
		playerIsAnimating = true;
		Animation* actionAnimation = nullptr;
		actionAnimation = Animation::createWithSpriteFrames(dead, 0.1f);
		auto action = Animate::create(actionAnimation);
		auto idleAnimation = Animation::createWithSpriteFrames(idle, 0.1f);
		auto idelAnimate = Animate::create(idleAnimation);
		auto seq = Sequence::create(action, idelAnimate, CCCallFunc::create(([this]() {
			playerIsAnimating = false;
		})), nullptr); 
		player->runAction(seq);
		if (HPbarPercentage > 0) {
			HPbarPercentage -= 20;
			pT->setPercentage(HPbarPercentage);
		}
		
	}
}

void HelloWorld::update(float dt)
{
	std::string str = time->getString();
	int number = atoi(str.c_str());
	if (number > 0) {
		number--;
		char result[10] = { 0 };
		sprintf(result, "%d", number);
		time->setString(result);
	}
	else
		unschedule(schedule_selector(HelloWorld::update));
}

void HelloWorld::attackCallback(Ref * pSender)
{
	Animation* actionAnimation = nullptr;
	if (playerIsAnimating == false) {
		playerIsAnimating = true;
		actionAnimation = Animation::createWithSpriteFrames(attack, 0.1f);
		auto action = Animate::create(actionAnimation);
		auto idleAnimation = Animation::createWithSpriteFrames(idle, 0.1f);
		auto idelAnimate = Animate::create(idleAnimation);
		auto seq = Sequence::create(action, idelAnimate, CCCallFunc::create(([this]() {
			playerIsAnimating = false;
		})), nullptr);
		player->runAction(seq);
		if (HPbarPercentage < 100) { 
			HPbarPercentage += 20;
			pT->setPercentage(HPbarPercentage);
			
		}
	}
}
