#pragma once
#include <stdio.h>
#include "cocos2d.h"
USING_NS_CC;

class GameSence : public cocos2d::Scene
{
public:
	enum GameSceneTag {
		BG = 97,
		STONE = 98,
		CHEESE = 99,
		MOUSE = 100,
		SHOOTLABEL = 101
	};
	static cocos2d::Scene* createScene();

	virtual bool init();

	virtual bool onTouchBegan(Touch *touch, Event *unused_event);

	//virtual void shootMenuCallback(Ref* pSender);

	CREATE_FUNC(GameSence);
	void menuCallback(cocos2d::Ref* pSender);

private:
	Sprite * mouse;

	Sprite* stone;

	Layer* mouseLayer;

	Layer* stoneLayer;

};