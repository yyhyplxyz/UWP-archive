#include "GameScene.h"

USING_NS_CC;

Scene* GameSence::createScene()
{
	auto scene = Scene::create();

	auto layer = GameSence::create();
	scene->addChild(layer);
	return scene;
}

// on "init" you need to initialize your instance
bool GameSence::init()
{
	//////////////////////////////
	// 1. super init first
	if (!Scene::init())
	{
		return false;
	}

	//add touch listener
	EventListenerTouchOneByOne* listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(GameSence::onTouchBegan, this);
	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();


	auto bg = Sprite::create("level-background-0.jpg");
	bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	this->addChild(bg, 0, GameSceneTag::BG);

	auto spritecache = SpriteFrameCache::getInstance();
	spritecache->addSpriteFramesWithFile("level-sheet.plist");
	mouse = Sprite::createWithSpriteFrameName("gem-mouse-0.png");
	mouse->setPosition(Vec2(origin.x + visibleSize.width / 2, 0));
	Animate* mouseAnimate = Animate::create(AnimationCache::getInstance()->getAnimation("mouseAnimation"));
	mouse->runAction(RepeatForever::create(mouseAnimate));

	stone = Sprite::create("stone.png");
	stone->setPosition(Vec2(560, 480));

	stoneLayer = Layer::create();
	stoneLayer->setPosition(Vec2(0, 0));
	stoneLayer->setAnchorPoint(Vec2(0, 0));
	stoneLayer->ignoreAnchorPointForPosition(false);

	this->addChild(stoneLayer, 1, GameSceneTag::STONE);

	stoneLayer->addChild(stone);
	mouseLayer = Layer::create();
	mouseLayer->setPosition(Vec2(0, origin.y + visibleSize.height / 2));
	mouseLayer->setAnchorPoint(Vec2(0, 0));
	//mouseLayer->ignoreAnchorPointForPosition(false);
	this->addChild(mouseLayer, 1, GameSceneTag::MOUSE);
	mouseLayer->addChild(mouse);
	auto shoot = Label::createWithSystemFont("Shoot", "Marker Felt", 80);
	auto menuItem = MenuItemLabel::create(shoot, CC_CALLBACK_1(GameSence::menuCallback, this));
	menuItem->setPosition(Vec2(visibleSize.width + origin.x - 150, visibleSize.height + origin.y - 140));

	auto menu = Menu::create(menuItem, NULL);
	menu->setAnchorPoint(Vec2::ZERO);
	menu->setPosition(Vec2::ZERO);
	this->addChild(menu, 1, GameSceneTag::SHOOTLABEL);

	return true;
}

bool GameSence::onTouchBegan(Touch *touch, Event *unused_event) {
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();
	auto location = touch->getLocation();
	auto shootLabel = this->getChildByTag(GameSceneTag::SHOOTLABEL);
	auto mouselocalPosition = mouseLayer->convertToNodeSpace(location);
	auto stoneWorldPosition = mouseLayer->convertToWorldSpace(mouse->getPosition());
	auto stoneLocalPosition = stoneLayer->convertToNodeSpace(stoneWorldPosition);
	bool isInShootLabel = shootLabel->getBoundingBox().containsPoint(location);
	if (isInShootLabel) {
		//CCLog("worldX == %f, worldY == %f", stoneWorldPosition.x, stoneWorldPosition.y);
		auto stoneMoveTo = MoveTo::create(0.5, stoneLocalPosition);
		stone->runAction(stoneMoveTo);
		auto mouseNewLocalPosition = mouseLayer->convertToNodeSpace(Vect(CCRANDOM_0_1() * visibleSize.width, CCRANDOM_0_1() * visibleSize.height));
		auto mouseMoveTo = MoveTo::create(0.5, mouseNewLocalPosition);
		mouse->runAction(mouseMoveTo);
		auto diamond = Sprite::create("diamond.png");
		Animate* diamondAnimate = Animate::create(AnimationCache::getInstance()->getAnimation("diamondAnimation"));
		diamond->runAction(RepeatForever::create(diamondAnimate));
		diamond->setPosition(stoneWorldPosition);
		this->addChild(diamond);
		return true;
	}
	else {

		//put cheese
		auto cheese = Sprite::create("cheese.png");
		cheese->setPosition(location);
		this->addChild(cheese);

		//mouse move to cheese
		auto moveTo = MoveTo::create(2, mouselocalPosition);
		mouse->runAction(moveTo);

		//cheese eaten by mouse
		auto fadeOut = FadeOut::create(2);
		auto callBackRemove = CallFunc::create([this, &cheese]() {
			this->removeChild(cheese);
		});

		auto cheeseSequence = Sequence::create(fadeOut, DelayTime::create(2), nullptr);
		cheese->runAction(cheeseSequence);
		return true;
	}
}


void GameSence::menuCallback(cocos2d::Ref* pSender) {
	auto origin = Point(30, 30);
	if (mouse->getPosition() != mouseLayer->convertToNodeSpace(origin)) {
		auto location = mouse->getPosition();
		location = mouseLayer->convertToWorldSpace(location);
		//auto stonepos = mouseLayer->convertToWorldSpace(mouse->getPosition);
		auto moveTo = MoveTo::create(0.5, stoneLayer->convertToNodeSpace(location));
		stone->runAction(moveTo);
		auto delayTime = DelayTime::create(0.5);
		auto func = CallFunc::create([this, location]() {
			auto _location = Point(10,20);
			auto moveTo = MoveTo::create(0.5, mouseLayer->convertToNodeSpace(_location));
			mouse->runAction(moveTo);
			auto diamond = Sprite::create("diamond.png");
			Animate* diamondAnimate = Animate::create(AnimationCache::getInstance()->getAnimation("diamondAnimation"));
			diamond->runAction(RepeatForever::create(diamondAnimate));
			diamond->setPosition(this->convertToNodeSpace(location));
			this->addChild(diamond);
			auto _delayTime = DelayTime::create(0.5);
			auto _func = CallFunc::create([this]() {
				stoneLayer->removeChild(stone);
				stone = Sprite::create("stone.png");
				stone->setPosition(Vec2(560, 480));
				stoneLayer->addChild(stone);
			});
			auto _seq = Sequence::create(_delayTime, _func, NULL);
			this->runAction(_seq);
		});
		auto seq = Sequence::create(delayTime, func, NULL);
		this->runAction(seq);
	}
}
