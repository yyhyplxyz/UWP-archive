﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLitePCL;
using System.IO;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Notifications;
using Windows.Data.Xml.Dom;
using Windows.ApplicationModel.DataTransfer;
using Todos.Models;
using System.Reflection;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Media.Imaging;
using Microsoft.Toolkit.Uwp.Notifications;
using Windows.Storage.Pickers;
using Windows.Graphics.Imaging;
using System.Text.RegularExpressions;
using Windows.Storage.AccessCache;
using System.Diagnostics;
using Windows.System;

namespace Todos.ViewModels
{
    public class TodoItemViewModel
    {
        private ObservableCollection<Models.TodoItem> allItems = new ObservableCollection<Models.TodoItem>();
        public ObservableCollection<Models.TodoItem> AllItems { get { return this.allItems; } }

        private Models.TodoItem selectedItem = default(Models.TodoItem);
        public Models.TodoItem SelectedItem { get { return selectedItem; } set { this.selectedItem = value; }  }

        public TodoItemViewModel()
        {
            using (var db = new SQLiteConnection("demo.db"))
            {
                using (var statement = db.Prepare("SELECT title,description, Date, DisplayedImagePath From TodoItem"))
                {
                    while (SQLiteResult.ROW == statement.Step())
                    {
                        this.allItems.Add(new Models.TodoItem((string)statement[0], (string)statement[1], DateTimeOffset.Parse(statement[2].ToString()), (string) statement[3]));
                    }
                }
            }
        }

        public void AddTodoItem(string title, string description, System.DateTimeOffset date, string DisplayPath="", BitmapImage myimage=null)
        {
            DisplayPath = "ms-appx:///Assets/" + DisplayPath;
            this.allItems.Add(new Models.TodoItem(title,description,date,DisplayPath, myimage));
            var db = App.conn;
                using (var TodoItem = db.Prepare(App.SQL_INSERT))
                {
                    TodoItem.Bind(1, title);
                    TodoItem.Bind(2, description);
                    TodoItem.Bind(3,date.ToString());
                    TodoItem.Bind(4, DisplayPath);
                    TodoItem.Bind(5, myimage);
                    TodoItem.Step();
                }
            
        }

        public void RemoveTodoItem()
        {
            // DIY
            
            string t = this.selectedItem.title;
            string d = this.selectedItem.description;
            var da = this.selectedItem.day;
            this.allItems.Remove(this.SelectedItem);
            // set selectedItem to null after remove
            this.selectedItem = null;
            
            using (var statement = App.conn.Prepare(App.SQL_DELETE))
            {
                statement.Bind(1, t);
                statement.Bind(2, d);
                statement.Bind(3, da.ToString());
                statement.Step();
            }
            this.selectedItem = null;
        }

        public void UpdateTodoItem(string title, string description, System.DateTimeOffset date, string DisplayPath = "", BitmapImage myimage = null)
        {
            // DIY
            var index = this.allItems.IndexOf(this.selectedItem);
            string t = "";
            t = this.selectedItem.title;
            this.selectedItem.title = title;
            this.selectedItem.description = description;
            this.selectedItem.day = date;
            this.selectedItem.DisplayedImagePath = "ms-appx:///Assets/" + DisplayPath;
            this.selectedItem.image = myimage;
            this.allItems.Remove(this.SelectedItem);
            this.allItems.Insert(index, this.selectedItem);
            var db = App.conn;

            try
            {
                using (var TodoItem = db.Prepare(App.SQL_UPDATE))
                {
                    TodoItem.Bind(1, title);
                    TodoItem.Bind(2, description);
                    TodoItem.Bind(3, date.ToString());
                    TodoItem.Bind(4, DisplayPath);
                    TodoItem.Bind(6, t);
                    TodoItem.Bind(5, myimage);
                    TodoItem.Step();
                }
            }
            catch (Exception ex)
            {
               
            }
            this.selectedItem = null;
        }
    }
    public class TodoViewModelManager
    {
        private static TodoItemViewModel myviewmodel;
        public static TodoItemViewModel getViewModel()
        {
            if(myviewmodel == null)
            myviewmodel = new TodoItemViewModel();
            return myviewmodel;
        }    
    }
}
