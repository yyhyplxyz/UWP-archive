﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Notifications;
using Windows.Data.Xml.Dom;
using Windows.ApplicationModel.DataTransfer;
using Todos.Models;
using System.Reflection;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Media.Imaging;
using Microsoft.Toolkit.Uwp.Notifications;
using Windows.Storage.Pickers;
using Windows.Graphics.Imaging;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage.AccessCache;
using SQLitePCL;
using System.Diagnostics;
using Windows.System;

//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace Todos
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>

    public sealed partial class MainPage : Page
    {

        public MainPage()
        {
            this.InitializeComponent();
            var viewTitleBar = Windows.UI.ViewManagement.ApplicationView.GetForCurrentView().TitleBar;
            viewTitleBar.BackgroundColor = Windows.UI.Colors.CornflowerBlue;
            viewTitleBar.ButtonBackgroundColor = Windows.UI.Colors.CornflowerBlue;
            this.ViewModel = ViewModels.TodoViewModelManager.getViewModel();
            TileUpdateManager.CreateTileUpdaterForApplication().EnableNotificationQueue(true);
        }

        ViewModels.TodoItemViewModel ViewModel { get; set; }
        string title;
        string detail;
        DateTimeOffset time;

        private List<TodoItem> getTodoItem(string search)
        {
            List<TodoItem> todos = new List<TodoItem>();
            TodoItem todo = null;
            var db = App.conn;
            using (var statement = db.Prepare("SELECT Title,Description,Date FROM TodoItem WHERE Title = ?"))
            {
                statement.Bind(1, search);
                while (SQLiteResult.ROW == statement.Step())
                {
                    todo = new TodoItem((string)statement[0], (string)statement[1], DateTimeOffset.Parse((string)statement[2]), (string)statement[2]);
                    todos.Add(todo);
                }
            }
            return todos;

        }

        private void search_Click(object sender, RoutedEventArgs e)
        {
            string text = Query.Text;
            List<TodoItem> todos = getTodoItem(text);
          
            String result = String.Empty;
            System.Text.StringBuilder DataQuery = new StringBuilder("%%");
            DataQuery.Insert(1, Query.Text);
            var db = App.conn;
            using (var statement = db.Prepare(App.SQL_SEARCH))
            {
                statement.Bind(1, DataQuery.ToString());
                statement.Bind(2, DataQuery.ToString());
                statement.Bind(3, DataQuery.ToString());
                while (SQLiteResult.ROW == statement.Step())
                {
                    result += statement[0].ToString() + " ";
                    result += statement[1].ToString() + " ";
                    result += statement[2].ToString() + "\n";
                }
            }

            if (result == String.Empty)
            {
                var box1 = new MessageDialog("Not find").ShowAsync();
            }
            else
            {
                var box2 = new MessageDialog(result).ShowAsync();
            }
     
    }
    
        private void TodoItem_ItemClicked(object sender, ItemClickEventArgs e)
        {
            ViewModel.SelectedItem = (Models.TodoItem)(e.ClickedItem);
            if (Window.Current.Bounds.Width <= 800)
                /*Frame.Navigate(typeof(NewPage), ViewModel);*/
                Frame.Navigate(typeof(NewPage), "");

            else
            {
                if (ViewModel.SelectedItem == null)
                {
                    CreateButton.Content = "Create";
                }
                else
                {
                    Title.Text = ViewModel.SelectedItem.title;
                    Details.Text = ViewModel.SelectedItem.description;
                    DatePicker.Date = ViewModel.SelectedItem.day;
                    CreateButton.Content = "Update";
                    this.title = Title.Text;
                    this.detail = Details.Text;
                    this.time = DatePicker.Date;
                }
            }
        }

        private void AddAppBarButton_Click(object sender, RoutedEventArgs e)
        {
            /* Frame.Navigate(typeof(NewPage), ViewModel);*/
            Frame.Navigate(typeof(NewPage), "");

        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            if (path == "ms-appx:///Assets/")
            {
                path = "ms-appx:///Assets/reminders.png";
            }
            if (ViewModel.SelectedItem == null)
            {
                if (Title.Text == "")
                {
                    var K = new MessageDialog("Title error!").ShowAsync();
                }
               else if (Details.Text == "")
                {
                    var K = new MessageDialog("details error!").ShowAsync();
                }
                else if (DatePicker.Date < DateTime.Now.Date)
                {
                    var K = new MessageDialog("dates error!").ShowAsync();
                }
                
                else ViewModel.AddTodoItem(Title.Text, Details.Text, DatePicker.Date, path);
            }

            else ViewModel.UpdateTodoItem(Title.Text, Details.Text, DatePicker.Date,path);
            updateTile();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        { 

            if(ViewModel.SelectedItem == null)
            {
                Title.Text = "";
                Details.Text = "";
                DatePicker.Date = DateTime.Now.Date;
                CreateButton.Content = "Create";
                ViewModel.SelectedItem = null;
            }
            else
            {
                Title.Text = title;
                Details.Text = detail;
                DatePicker.Date = time;

            }
        }



        private void MenuFlyoutItem_Click_1(object sender, RoutedEventArgs e)
        {
            var data = (sender as FrameworkElement).DataContext;
            var item = ToDoListView.ContainerFromItem(data) as ListViewItem;
            ViewModel.SelectedItem = item.Content as TodoItem;
            Frame.Navigate(typeof(NewPage), "");
            /*Frame.Navigate(typeof(NewPage), ViewModel);*/

        }
        public string path;
        private void MenuFlyoutItem_Click_2(object sender, RoutedEventArgs e)
        {
            var data = (sender as FrameworkElement).DataContext;
            var item = ToDoListView.ContainerFromItem(data) as ListViewItem;
            ViewModel.SelectedItem = item.Content as TodoItem;
            ViewModel.RemoveTodoItem();
            ViewModel.SelectedItem = null;
        }
        private async void selectButton_Click(object sender, RoutedEventArgs e)
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.ViewMode = Windows.Storage.Pickers.PickerViewMode.Thumbnail;
            picker.SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.PicturesLibrary;
            picker.FileTypeFilter.Add(".jpg");
            picker.FileTypeFilter.Add(".jpeg");
            picker.FileTypeFilter.Add(".png");

            Windows.Storage.StorageFile file = await picker.PickSingleFileAsync();
            //var composite = new ApplicationDataCompositeValue();
            if (file != null)
            {
                string Token = StorageApplicationPermissions.FutureAccessList.Add(file);
                //composite["image"] = Token;
                var inputFile = SharedStorageAccessManager.AddFile(file);
                var destination = await ApplicationData.Current.LocalFolder.CreateFileAsync("Cropped.jpg", CreationCollisionOption.ReplaceExisting);//在应用文件夹中建立文件用来存储裁剪后的图像  
                var destinationFile = SharedStorageAccessManager.AddFile(destination);
                var options = new LauncherOptions();
                options.TargetApplicationPackageFamilyName = "Microsoft.Windows.Photos_8wekyb3d8bbwe";

                //待会要传入的参数  
                var parameters = new ValueSet();
                parameters.Add("InputToken", inputFile);                //输入文件  
                parameters.Add("DestinationToken", destinationFile);    //输出文件  
                parameters.Add("ShowCamera", false);                    //它允许我们显示一个按钮，以允许用户采取当场图象(但是好像并没有什么卵用)  
                parameters.Add("EllipticalCrop", true);                 //截图区域显示为圆（最后截出来还是方形）  
                parameters.Add("CropWidthPixals", 300);
                parameters.Add("CropHeightPixals", 300);

                //调用系统自带截图并返回结果  
                var result = await Launcher.LaunchUriForResultsAsync(new Uri("microsoft.windows.photos.crop:"), options, parameters);

                //按理说下面这个判断应该没问题呀，但是如果裁剪界面点了取消的话后面会出现异常，所以后面我加了try catch  
                if (result.Status == LaunchUriStatus.Success && result.Result != null)
                {
                    //对裁剪后图像的下一步处理  
                    try
                    {
                        // 载入已保存的裁剪后图片  
                        var stream = await destination.OpenReadAsync();
                        var bitmap = new BitmapImage();
                        await bitmap.SetSourceAsync(stream);

                        // 显示  
                        imagePicker.Source = bitmap;
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message + ex.StackTrace);
                    }
                }

            }
            /*
            BitmapImage new_img = new Windows.UI.Xaml.Media.Imaging.BitmapImage(new System.Uri(file.Path));
            using (IRandomAccessStream fileStream = await file.OpenAsync(Windows.Storage.FileAccessMode.Read))
            {
                BitmapImage bitmapImage = new BitmapImage();

                await bitmapImage.SetSourceAsync(fileStream);
                imagePicker.Source = bitmapImage;
            }*/
            int index = file.Path.LastIndexOf("\\");
            path = file.Path.Substring(index + 1, file.Path.Length - index -1 );

        }
        private void MenuFlyoutItem_Click(object sender, RoutedEventArgs e)
        {
            DataTransferManager.ShowShareUI();

            dynamic ori = e.OriginalSource;
            ViewModel.SelectedItem = (TodoItem)ori.DataContext;
            ShareSourceLoad(ViewModel.SelectedItem);

        }
        private void ShareSourceLoad(TodoItem selected)
        {
            DataTransferManager dataTransferManager = DataTransferManager.GetForCurrentView();
            dataTransferManager.DataRequested += new TypedEventHandler<DataTransferManager, DataRequestedEventArgs>(this.onShareDataRequested);
        }

        private void onShareDataRequested(DataTransferManager sender, DataRequestedEventArgs args)
        {
            var dp = args.Request.Data;
            var def = args.Request.GetDeferral();
            RandomAccessStreamReference photo;
            if (ViewModel.SelectedItem.DisplayedImagePath == "Assets/reminders.png")
            {
               photo = RandomAccessStreamReference.CreateFromUri(new Uri("ms-appx:///Assets/reminders.png"));
            }
            else
            {
                int index = ViewModel.SelectedItem.DisplayedImagePath.LastIndexOf("\\");
                string newpath = ViewModel.SelectedItem.DisplayedImagePath.Substring(index + 1, ViewModel.SelectedItem.DisplayedImagePath.Length - index - 1);
                //string t = "ms-appx:///Assets/" + newpath;
                photo = RandomAccessStreamReference.CreateFromUri(new Uri(newpath));
            } 
          
            dp.Properties.Title = ViewModel.SelectedItem.title;
            dp.Properties.Description = ViewModel.SelectedItem.description;
            dp.SetBitmap(photo);
            dp.SetText(ViewModel.SelectedItem.title);
            def.Complete();
        }
        private void updateTile()
        {
            var updater = TileUpdateManager.CreateTileUpdaterForApplication();
            updater.EnableNotificationQueue(true);
            updater.Clear();
            foreach (var todo in ViewModel.AllItems)
            {

                XmlDocument xml = new XmlDocument();
                xml.LoadXml(File.ReadAllText("try.xml"));
                XmlNodeList text = xml.GetElementsByTagName("text");
                XmlNodeList image = xml.GetElementsByTagName("image");
                for (int i = 0; i < text.Count; i++)
                {
                    ((XmlElement)text[i]).InnerText = todo.title;
                    i++;
                    ((XmlElement)text[i]).InnerText = todo.description;
                }
                foreach (var element in image)
                    ((XmlElement)element).SetAttribute("src", "Assets\\2.jpg");

                var notification = new TileNotification(xml);
                updater.Update(notification);
            }
        }
        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            // base.OnNavigatedFrom(e);
            bool suspending = ((App)App.Current).issuspend;
            if (suspending)
            {
                var composite = new ApplicationDataCompositeValue();
                composite["title"] = Title.Text;
                composite["Detail"] = Details.Text;
                composite["Date"] = DatePicker.Date;
                string t = "ms-appx:///Assets/" + path;
                composite["imagepath"] = t;
                int i = 0;
                foreach (var todo in ViewModel.AllItems)
                {
                    composite["Item" + i] = todo.completed;
                    i++;
                }

                ApplicationData.Current.LocalSettings.Values["TheWorkInProgress"] = composite;
            }
            //updateTile();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (e.NavigationMode == NavigationMode.New)
            {
                ApplicationData.Current.LocalSettings.Values.Remove("TheWorkInProgress");
            }
            else
            {
                if (ApplicationData.Current.LocalSettings.Values.ContainsKey("TheWorkInProgress"))
                {
                    var composite = ApplicationData.Current.LocalSettings.Values["TheWorkInProgress"] as ApplicationDataCompositeValue;
                    Title.Text = Convert.ToString(composite["title"]);
                    Details.Text = (string)composite["Detail"];
                    DatePicker.Date = (DateTimeOffset)composite["Date"];
                    path = (string)composite["imagepath"];
                    Uri imageUri = new Uri(path, UriKind.Absolute);
                    BitmapImage imageBitmap = new BitmapImage(imageUri);
                    imagePicker.Source = imageBitmap;
                    // imagePicker.Source = (ImageSource) composite["imagepath"];
                    int i = 0;
                    foreach (var todo in ViewModel.AllItems)
                    {
                        todo.completed = Convert.ToBoolean(composite["Item" + i]);
                        i++;

                    }


                }
            }
            if (e.Parameter.GetType() == typeof(ViewModels.TodoItemViewModel))
            {
                this.ViewModel = (ViewModels.TodoItemViewModel)(e.Parameter);
            }
            TileUpdateManager.CreateTileUpdaterForApplication().EnableNotificationQueue(true);
            updateTile();
        }

    }
}

/*
if (imageFile != null)
                {
                    string Token = StorageApplicationPermissions.FutureAccessList.Add(imageFile);
composite["image"] = Token;
                }
    

if (composite.ContainsKey("image"))
                {
                    string Token = (string)composite["image"];
readImage(Token);
                }

private async void readImage(string Token)
{
    BitmapImage srcImage = new BitmapImage();
    imageFile = await StorageApplicationPermissions.FutureAccessList.GetFileAsync(Token);
    if (imageFile != null)
    {
        using (IRandomAccessStream stream = await imageFile.OpenAsync(FileAccessMode.Read))
        {
            await srcImage.SetSourceAsync(stream);
            MyNowImage.Source = srcImage;
        }
    }
}*/