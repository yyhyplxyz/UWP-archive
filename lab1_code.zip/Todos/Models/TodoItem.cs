﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.Storage;
using Windows.Storage.Streams;
namespace Todos.Models
{
    class TodoItem
    {
        public string id;
        public string title { get; set; }
        public string description { get; set; }
        public bool completed { get; set; }
        public System.DateTimeOffset day;
        public string DisplayedImagePath { get; set; }
        public string imageName { get; set; }
        public ImageSource image;
        //日期字段自己写

        public TodoItem(string title, string description, System.DateTimeOffset date, string imageName = "")
        {
            this.id = Guid.NewGuid().ToString(); //生成id
            this.title = title;
            this.description = description;
            this.completed = false; //默认为未完成
            this.day = date;
            DisplayedImagePath = "Assets/reminders.png";
            this.imageName = imageName;
            setImg();
        }
        public async void setImg()
        {
            if (imageName == "")
            {
                image = new BitmapImage(new Uri("ms-appx:///Assets/reminders.png"));
            }
            else
            {
                var file = await ApplicationData.Current.LocalFolder.GetFileAsync(imageName);
                IRandomAccessStream fileStream = await file.OpenAsync(FileAccessMode.Read);
                BitmapImage bitmapImage = new BitmapImage();
                await bitmapImage.SetSourceAsync(fileStream);
                image = bitmapImage;
            }
        }
    }
    class Converter: IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            bool myValue = (bool)value;
            if (myValue)
            {
                return Visibility.Visible;
            }
            else
            {
                return Visibility.Collapsed;
            }
        }
        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
}
