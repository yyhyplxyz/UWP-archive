﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Notifications;
using Windows.Data.Xml.Dom;
using Windows.ApplicationModel.DataTransfer;
using Todos.Models;
using System.Reflection;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Media.Imaging;
using Microsoft.Toolkit.Uwp.Notifications; // Notifications library

//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace Todos
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>

    public sealed partial class MainPage : Page
    {

        /*public void Tiletry()
        {
            // In a real app, these would be initialized with actual data
            string from = "Jennifer Parker";
            string subject = "Photos from our trip";
            string body = "Check out these awesome photos I took while in New Zealand!";


            // TODO - all values need to be XML escaped


            // Construct the tile content as a string
            string content = $@"
<tile>
    <visual>
 
        <binding template='TileMedium'>
            <text>{from}</text>
            <text hint-style='captionSubtle'>{subject}</text>
            <text hint-style='captionSubtle'>{body}</text>
        </binding>
 
        <binding template='TileWide'>
            <text hint-style='subtitle'>{from}</text>
            <text hint-style='captionSubtle'>{subject}</text>
            <text hint-style='captionSubtle'>{body}</text>
        </binding>
 
    </visual>
</tile>";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(content);

            // Then create the tile notification
            var notification = new TileNotification(doc);
        }*/
        public void Tiletry()
        {
            // In a real app, these would be initialized with actual data
            string from = "Jennifer Parker";
            string subject = "Photos from our trip";
            string body = "Check out these awesome photos I took while in New Zealand!";


            // Construct the tile content
            TileContent content = new TileContent()
            {
                Visual = new TileVisual()
                {
                    TileMedium = new TileBinding()
                    {
                        Content = new TileBindingContentAdaptive()
                        {
                            Children =
                {
                    new AdaptiveText()
                    {
                        Text = from
                    },

                    new AdaptiveText()
                    {
                        Text = subject,
                        HintStyle = AdaptiveTextStyle.CaptionSubtle
                    },

                    new AdaptiveText()
                    {
                        Text = body,
                        HintStyle = AdaptiveTextStyle.CaptionSubtle
                    }
                }
                        }
                    },

                    TileWide = new TileBinding()
                    {
                        Content = new TileBindingContentAdaptive()
                        {
                            Children =
                {
                    new AdaptiveText()
                    {
                        Text = from,
                        HintStyle = AdaptiveTextStyle.Subtitle
                    },

                    new AdaptiveText()
                    {
                        Text = subject,
                        HintStyle = AdaptiveTextStyle.CaptionSubtle
                    },

                    new AdaptiveText()
                    {
                        Text = body,
                        HintStyle = AdaptiveTextStyle.CaptionSubtle
                    }
                }
                        }
                    }
                }
            };
            // Create the tile notification
            var notification = new TileNotification(content.GetXml());
            // Send the notification to the primary tile
            TileUpdateManager.CreateTileUpdaterForApplication().Update(notification);
        }

        public MainPage()
        {
            this.InitializeComponent();
            var viewTitleBar = Windows.UI.ViewManagement.ApplicationView.GetForCurrentView().TitleBar;
            viewTitleBar.BackgroundColor = Windows.UI.Colors.CornflowerBlue;
            viewTitleBar.ButtonBackgroundColor = Windows.UI.Colors.CornflowerBlue;
            this.ViewModel = new ViewModels.TodoItemViewModel();
            Tiletry();
           // updateTile();
        }

        ViewModels.TodoItemViewModel ViewModel = ViewModels.TodoItemViewModel.getInstance();
        string title;
        string detail;
        DateTimeOffset time;
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (e.Parameter.GetType() == typeof(ViewModels.TodoItemViewModel))
            {
                this.ViewModel = (ViewModels.TodoItemViewModel)(e.Parameter);
            }
        }

        private void TodoItem_ItemClicked(object sender, ItemClickEventArgs e)
        {
            ViewModel.SelectedItem = (Models.TodoItem)(e.ClickedItem);
            if (Window.Current.Bounds.Width <= 800)
                Frame.Navigate(typeof(NewPage));
            else
            {
                if (ViewModel.SelectedItem == null)
                {
                    CreateButton.Content = "Create";
                }
                else
                {
                    Title.Text = ViewModel.SelectedItem.title;
                    Details.Text = ViewModel.SelectedItem.description;
                    DatePicker.Date = ViewModel.SelectedItem.day;
                    CreateButton.Content = "Update";
                    this.title = Title.Text;
                    this.detail = Details.Text;
                    this.time = DatePicker.Date;
                }
            }
        }

        private void AddAppBarButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(NewPage));
            
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SelectedItem == null)
            {
                if (Title.Text == "")
                {
                    var K = new MessageDialog("Title error!").ShowAsync();
                }
               else if (Details.Text == "")
                {
                    var K = new MessageDialog("details error!").ShowAsync();
                }
                else if (DatePicker.Date < DateTime.Now.Date)
                {
                    var K = new MessageDialog("dates error!").ShowAsync();
                }
                else ViewModel.AddTodoItem(Title.Text, Details.Text, DatePicker.Date);
            }
            else ViewModel.UpdateTodoItem(Title.Text, Details.Text, DatePicker.Date);
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        { 

            if(ViewModel.SelectedItem == null)
            {
                Title.Text = "";
                Details.Text = "";
                DatePicker.Date = DateTime.Now.Date;
                CreateButton.Content = "Create";
                ViewModel.SelectedItem = null;
            }
            else
            {
                Title.Text = title;
                Details.Text = detail;
                DatePicker.Date = time;

            }
        }



        private void MenuFlyoutItem_Click_1(object sender, RoutedEventArgs e)
        {
            var data = (sender as FrameworkElement).DataContext;
            var item = ToDoListView.ContainerFromItem(data) as ListViewItem;
            ViewModel.SelectedItem = item.Content as TodoItem;
            Frame.Navigate(typeof(NewPage));

        }

        private void MenuFlyoutItem_Click_2(object sender, RoutedEventArgs e)
        {
            var data = (sender as FrameworkElement).DataContext;
            var item = ToDoListView.ContainerFromItem(data) as ListViewItem;
            ViewModel.SelectedItem = item.Content as TodoItem;
            ViewModel.RemoveTodoItem();
            ViewModel.SelectedItem = null;
        }
        private async void selectButton_Click(object sender, RoutedEventArgs e)
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.ViewMode = Windows.Storage.Pickers.PickerViewMode.Thumbnail;
            picker.SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.PicturesLibrary;
            picker.FileTypeFilter.Add(".jpg");
            picker.FileTypeFilter.Add(".jpeg");
            picker.FileTypeFilter.Add(".png");
            Windows.Storage.StorageFile file = await picker.PickSingleFileAsync();
            BitmapImage new_img = new Windows.UI.Xaml.Media.Imaging.BitmapImage(new System.Uri(file.Path));
            using (IRandomAccessStream fileStream = await file.OpenAsync(Windows.Storage.FileAccessMode.Read))
            {
                BitmapImage bitmapImage = new BitmapImage();

                await bitmapImage.SetSourceAsync(fileStream);
                imagePicker.Source = bitmapImage;
            }
        }
        private void MenuFlyoutItem_Click(object sender, RoutedEventArgs e)
        {
            DataTransferManager.ShowShareUI();

            dynamic ori = e.OriginalSource;
            ViewModel.SelectedItem = (TodoItem)ori.DataContext;
            ShareSourceLoad(ViewModel.SelectedItem);

        }
        private void ShareSourceLoad(TodoItem selected)
        {
            DataTransferManager dataTransferManager = DataTransferManager.GetForCurrentView();
            dataTransferManager.DataRequested += new TypedEventHandler<DataTransferManager, DataRequestedEventArgs>(this.onShareDataRequested);
        }

        private void onShareDataRequested(DataTransferManager sender, DataRequestedEventArgs args)
        {
            var dp = args.Request.Data;
            var def = args.Request.GetDeferral();
            var photo = RandomAccessStreamReference.CreateFromUri(new Uri("ms-appx:///Assets/background.jpg"));


            dp.Properties.Title = ViewModel.SelectedItem.title;
            dp.Properties.Description = ViewModel.SelectedItem.description;
            dp.SetBitmap(photo);
            dp.SetText(ViewModel.SelectedItem.title);
            def.Complete();
            ;
        }
        private void updateTile()
        {
            var updater = TileUpdateManager.CreateTileUpdaterForApplication();
            updater.EnableNotificationQueue(true);
           // updater.Clear();
            foreach (var todo in ViewModel.AllItems)
            {

                XmlDocument xml = new XmlDocument();
                xml.LoadXml(File.ReadAllText("try.xml"));
                XmlNodeList text = xml.GetElementsByTagName("text");
                XmlNodeList image = xml.GetElementsByTagName("image");
                for (int i = 0; i < text.Count; i++)
                {
                    ((XmlElement)text[i]).InnerText = todo.title;
                    i++;
                    ((XmlElement)text[i]).InnerText = todo.description;
                }
                foreach (var element in image)
                    ((XmlElement)element).SetAttribute("src", "Assets\\2.jpg");

                var notification = new TileNotification(xml);
                updater.Update(notification);
            }
        }

    }
}
